import mongoose from "mongoose";
import type { Document, Model } from "mongoose";

export interface ICountry extends Document {
  _id: mongoose.Types.ObjectId;
  code: string; 
  name: string; 
  slug: string; 
}

const CountrySchema = new mongoose.Schema<ICountry>(
  {
    code: {
      type: String,
      required: true,
      unique: true,
      uppercase: true, // Tự động viết hoa
      index: true,
    },
    name: { type: String, required: true, trim: true },
    slug: { type: String, required: true, index: true }, // Bỏ unique ở slug, dùng iso làm key chính
  },
  { timestamps: true }
);

const Country: Model<ICountry> =
  mongoose.models.Country || mongoose.model<ICountry>("Country", CountrySchema);

export default Country;
