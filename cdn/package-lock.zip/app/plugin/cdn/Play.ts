import { Request, Response } from "express";
import { Types } from "mongoose";
import Episode, { IEpisode, ISubtitleResource, IVideoResource } from "../../model/Episode"; // Import thêm interface IVideoResource
import { localTokenService } from "./services/LocalTokenService";
import { decrypt, Encrypt } from "../../../utils/crypto/fly";
import { decryptAES } from "../../../utils/crypto/fly2";
import Movie from "../../model/Movie";
import Season from "../../model/Season";

class PlayController {
  constructor() {
    this.getSecuredEpisodeData = this.getSecuredEpisodeData.bind(this);
  }

  public getFilm = async (req: Request, res: Response) => {
    try {
      const { slug } = req.params;
      const { ct, iv, type } = req.query;

      const decryptedSlugStr = await decrypt(slug);
      const obj = JSON.parse(decryptedSlugStr);

      // 2. Giải mã Fingerprint trình duyệt (x2Data)
      const x2Data = await decryptAES(ct as string, iv as string);
      const requestIP = this.getClientIp(req);
      const requestUA = req.headers["user-agent"] || "";

      // 3. Kiểm tra bảo mật
      const securityCheck = this.verifySecurity(
        obj,
        x2Data,
        requestIP,
        requestUA
      );

      if (!securityCheck.isValid) {
        console.warn(
          `[Security Challenge] IP: ${requestIP} - Reason: ${securityCheck.reason}`
        );

        const captchaHtmlContent = `
            <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; height:100%; padding: 20px; text-align:center; font-family: sans-serif; color: #fff;">
                <h3 style="margin-bottom: 10px; color: #e74c3c;">Xác thực bảo mật</h3>
                <p style="font-size: 14px; margin-bottom: 20px; opacity: 0.8;">
                    Hệ thống phát hiện bất thường (${securityCheck.reason}).<br>
                    Vui lòng xác thực để tiếp tục xem phim.
                </p>
            </div>
        `;

        const encryptedView = Encrypt(captchaHtmlContent);

        return res.json({
          action: "captcha",
          view: encryptedView,
          reason: securityCheck.reason,
        });
      }

      // Query Database
      var phim = await Movie.findOne({ slug: obj.phim });
      var phan = await Season.findOne({
        slug: obj.phan,
        movie_id: phim?._id,
      });

      // Ở đây biến là 'tap', không phải 'episode'
      var tap = await Episode.findOne({
        slug: obj.tap,
        season_id: phan?._id,
      }).select("name description thumbnail videos subtitles type"); 
      // Lưu ý: select thêm field nếu cần

      if (!tap || !phan || !phim) {
        return res.status(404).json({ message: "Episode not found" });
      }

      // --- LOGIC MỚI: TÌM VIDEO THEO TYPE ---
      // Ưu tiên lấy type từ query, nếu không có thì lấy mặc định là 'phude' hoặc cái đầu tiên
      const requestedType = (type as string) || "phude";
      
      const selectedVideo: IVideoResource | undefined = tap.videos.find(
        (v) => v.type === requestedType
      );

      // Nếu không tìm thấy type yêu cầu, return lỗi hoặc fallback về video đầu tiên (tùy logic business)
      if (!selectedVideo) {
         return res.status(404).json({ message: `Video source type '${requestedType}' not found.` });
      }

      // --- BẢO MẬT: TẠO SECRET VÀ HASH USER-AGENT ---
      const playbackSecret = localTokenService.generateRandomSecret();
      const clientIp = this.getClientIp(req);
      const userAgent = req.headers["user-agent"] || "";
      const uaHash = localTokenService.hashUserAgent(userAgent);


      const encryptedToken = localTokenService.encrypt({
        id: tap._id.toString(),
        type: selectedVideo.type, 
        ip: clientIp,
        ua: uaHash,
        exp: Date.now() + 10800000, // 3 hours
        secret: playbackSecret,
      });

      const host = `${req.protocol}://${req.get("host")}`;
      const localProxyUrl = `${host}/stream/${encryptedToken}`;

      const skipConfig = {
        intro: selectedVideo.skip_intro,
        outro: selectedVideo.skip_outro,
      };

      const sources = [
        {
          file: localProxyUrl,
          label: selectedVideo.quality,
          type: "hls",
          default: true,
        },
      ];

      const tracks = tap.subtitles.map((sub: ISubtitleResource) => ({
        file: sub.url,
        label: sub.label,
        kind: "captions",
        default: sub.language === "vi",
      }));

      return res.json({
        ...obj,
        status: "success",
        session: {
          secret: playbackSecret,
          token: encryptedToken,
        },
        playlist: [
          {
            title: tap.name,
            description: tap.description,
            image: tap.thumbnail,
            sources: sources,
            tracks: tracks,
          },
        ],
        skip: skipConfig,
      });
    } catch (error) {
      console.error("Error in PlayController getFilm:", error);
      return res
        .status(500)
        .json({ action: "error", message: "INTERNAL_SERVER_ERROR" });
    }
  };

  private verifySecurity(
    obj: any,
    x2Data: any,
    reqIP: string,
    reqUA: string
  ): { isValid: boolean; reason?: string } {
    if (obj.userAgent !== reqUA) {
      return {
        isValid: false,
        reason: "User-Agent mismatch (Slug vs Request)",
      };
    }

    if (x2Data.browser && x2Data.browser.userAgent !== reqUA) {
      return {
        isValid: false,
        reason: "User-Agent mismatch (Fingerprint vs Request)",
      };
    }

    const normalizedSlugIP = obj.ip.replace("::ffff:", "");
    const normalizedReqIP = reqIP.replace("::ffff:", "");

    if (normalizedSlugIP !== normalizedReqIP) {
      return { isValid: false, reason: "IP address changed" };
    }

    if (x2Data.browser && x2Data.browser.webdriver === true) {
      return { isValid: false, reason: "Automation tool detected (Webdriver)" };
    }

    if (
      x2Data.screen &&
      (x2Data.screen.width === 0 || x2Data.screen.height === 0)
    ) {
      return { isValid: false, reason: "Invalid screen resolution" };
    }

    if (
      obj.deviceType === "PC" &&
      x2Data.other &&
      x2Data.other.plugins.length === 0
    ) {
      return { isValid: false, reason: "No plugins detected on PC" };
    }

    const LINK_EXPIRY_MS = 3 * 60 * 60 * 1000; // 3 tiếng
    const now = Date.now();
    const linkTime = parseInt(obj.timestamp);

    if (now - linkTime > LINK_EXPIRY_MS) {
      return { isValid: false, reason: "Link expired" };
    }

    return { isValid: true };
  }

  private getClientIp(req: Request): string {
    const ip =
      (req.headers["x-forwarded-for"] as string) ||
      req.socket.remoteAddress ||
      "";
    return ip.split(",")[0].trim();
  }

  public async getSecuredEpisodeData(req: Request, res: Response) {
    const { episodeId } = req.params;
    const { type } = req.query; // Lấy type từ query

    if (!Types.ObjectId.isValid(episodeId)) {
      return res.status(400).json({ message: "Invalid Episode ID" });
    }

    try {
      const episode: IEpisode | null = await Episode.findById(episodeId, {
        name: 1,
        description: 1,
        thumbnail: 1,
        videos: 1,
        subtitles: 1,
      });

      if (!episode)
        return res.status(404).json({ message: "Episode not found" });

      // --- LOGIC MỚI: TÌM VIDEO THEO TYPE ---
      const requestedType = (type as string) || "phude";
      
      const selectedVideo = episode.videos.find(v => v.type === requestedType);

      if (!selectedVideo) {
        return res.status(404).json({ message: `Video source type '${requestedType}' not found.` });
      }

      // --- BẢO MẬT ---
      const playbackSecret = localTokenService.generateRandomSecret();
      const clientIp = this.getClientIp(req);
      const userAgent = req.headers["user-agent"] || "";
      const uaHash = localTokenService.hashUserAgent(userAgent);

      // Tạo Token Mã Hóa
      const encryptedToken = localTokenService.encrypt({
        id: episodeId,
        type: selectedVideo.type, // Thay index bằng type
        ip: clientIp,
        ua: uaHash,
        exp: Date.now() + 10800000, 
        secret: playbackSecret, 
      });

      const host = `${req.protocol}://${req.get("host")}`;
      const localProxyUrl = `${host}/stream/${encryptedToken}`;

      const skipConfig = {
        intro: selectedVideo.skip_intro,
        outro: selectedVideo.skip_outro,
      };

      const sources = [
        {
          file: localProxyUrl,
          label: selectedVideo.quality,
          type: "hls",
          default: true,
        },
      ];

      const tracks = episode.subtitles.map((sub: ISubtitleResource) => ({
        file: sub.url,
        label: sub.label,
        kind: "captions",
        default: sub.language === "vi",
      }));

      return res.json({
        action: "play",
        session: {
          secret: playbackSecret,
          token: encryptedToken,
        },
        playlist: [
          {
            title: episode.name,
            description: episode.description,
            image: episode.thumbnail,
            sources: sources,
            tracks: tracks,
          },
        ],
        skip: skipConfig,
      });
    } catch (error) {
      console.error("Error in PlayController getSecuredEpisodeData:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
}

export default new PlayController();