import Redis from "ioredis";

// Cấu hình Redis (sửa lại host/port theo server của bạn)
const redis = new Redis({
  host: process.env.REDIS_HOST || "127.0.0.1",
  port: Number(process.env.REDIS_PORT) || 6379,
  // password: process.env.REDIS_PASSWORD, 
});

redis.on("connect", () => console.log("✅ Redis Connected"));
redis.on("error", () => console.error(" Redis Error"));

export default redis;