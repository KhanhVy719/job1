import mongoose from "mongoose";

const connectDB = async () => {
  const MONGODB_URI: string = process.env.MONGODB_URI || "";

  if (!MONGODB_URI) {
    console.error("Lỗi: Chưa cấu hình MONGODB_URI trong file .env");
    process.exit(1);
  }

  try {
    await mongoose.connect(MONGODB_URI);
    console.log("MongoDB Connected Successfully");
  } catch  {
    console.error(" Lỗi kết nối Database:");
    process.exit(1);
  }
};

export default connectDB;