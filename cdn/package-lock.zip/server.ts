// Loại bỏ các lệnh gọi crawler bị lặp lại và lỗi cú pháp ở đầu tệp.

import express from "express";
import type { Express } from "express";
import dotenv from "dotenv";
import cookieParser from "cookie-parser";
import { createServer } from "http";
import cors from "cors";
import routes from "./routes/web";
import stream from "./routes/stream";

import connectDB from "./utils/mongodb";

if (process.env.NODE_ENV !== "production") {
  dotenv.config();
}

connectDB();
const PORT: number = Number(process.env.PORT) || 8001;
const HOST_NAME: string = process.env.URL || "localhost";

const app: Express = express();

const whitelist = [
  "http://localhost:3000",
  "https://localhost:3000",
  "http://127.0.0.1:3000",
  "https://127.0.0.1:3000",
  "http://localhost:8000",
  "https://localhost:8000",
  "http://127.0.0.1:8000",
  "https://127.0.0.1:8000",
  "http://localhost:5000",
  "https://localhost:5000",
  "http://127.0.0.1:8080",
  "https://127.0.0.1:8080",
  "https://tungmmo.id.vn",
  "https://api.tungmmo.id.vn",
  "https://super.tungmmo.id.vn",
];

app.use(
  cors({
    origin: function (origin, callback) {
      if (!origin || whitelist.indexOf(origin) !== -1) {
        callback(null, true);
      } else {
        callback(new Error("Not allowed by CORS"));
      }
    },
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE"],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Playback-Session', 'Accept', 'Origin', 'X-Requested-With'],
    credentials: true,
  })
);

const httpServer = createServer(app);

app.use(cookieParser());
app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use("/api/v1", routes);
app.use("/", stream);

app.set("view engine", "ejs");
app.set("views", "./views");

httpServer.listen(PORT, HOST_NAME as any, () => {
  // console.clear();
  console.info(`Server đang chạy trên ${HOST_NAME}:${PORT}`);
});
