import express from 'express';
import StreamController from '../app/plugin/cdn/Stream';
// Assuming Play is in this location, adjust if needed
import Play from '../app/plugin/cdn/Play'; 
import verifyCsrfToken from '../app/middleware/verifyCsrfToken'
const router = express.Router();

router.get(
 '/captcha/t/:slug', 
 verifyCsrfToken,Play.getFilm 
);

router.get("/stream/:encryptedToken", StreamController.handleStream);

router.get("/stream/:encryptedToken/seg/*", StreamController.streamSegment); // <-- FIX APPLIED HERE

export default router;